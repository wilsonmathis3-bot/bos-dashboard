import { forwardRef } from "react";
import { Category, Integration } from "@/data/integrations";
import IntegrationCard from "@/components/IntegrationCard";

interface CategorySectionProps {
  category: Category;
  integrations: Integration[];
}

const CategorySection = forwardRef<HTMLElement, CategorySectionProps>(
  ({ category, integrations }, ref) => {
    return (
      <section
        id={category.id}
        ref={ref}
        className="relative py-20 sm:py-28"
      >
        {/* Background image with overlay */}
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center opacity-10"
            style={{ backgroundImage: `url(${category.image})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e1a] via-transparent to-[#0a0e1a]" />
        </div>

        <div className="relative container max-w-5xl mx-auto">
          {/* Category header */}
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-3 h-3 rounded-full animate-glow-pulse"
                style={{ backgroundColor: category.color }}
              />
              <span
                className="font-mono text-xs tracking-wider uppercase"
                style={{ color: category.color }}
              >
                {category.id}
              </span>
            </div>
            <h2
              className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-3"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              {category.title}
            </h2>
            <p className="text-white/50 text-base sm:text-lg max-w-2xl">
              {category.subtitle}
            </p>
          </div>

          {/* Integration cards */}
          <div className="grid gap-4">
            {integrations.map((integration, index) => (
              <IntegrationCard
                key={integration.id}
                integration={integration}
                category={category}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>
    );
  }
);

CategorySection.displayName = "CategorySection";
export default CategorySection;
