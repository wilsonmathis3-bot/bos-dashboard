import { useState, useEffect } from "react";
import { Category } from "@/data/integrations";

interface NavigationProps {
  categories: Category[];
  activeCategory: string | null;
  onCategoryClick: (id: string) => void;
}

export default function Navigation({ categories, activeCategory, onCategoryClick }: NavigationProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#0a0e1a]/90 backdrop-blur-xl border-b border-white/5 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-[#00f0ff] animate-glow-pulse" />
          <span className="font-mono text-xs text-white/60 tracking-wider uppercase">
            BOS AI Whitespace Atlas
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onCategoryClick(cat.id)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                activeCategory === cat.id
                  ? "text-white bg-white/10"
                  : "text-white/40 hover:text-white/70 hover:bg-white/5"
              }`}
              style={{
                borderBottom: activeCategory === cat.id ? `2px solid ${cat.color}` : "2px solid transparent",
              }}
            >
              {cat.title.split(" & ")[0]}
            </button>
          ))}
          <button
            onClick={() => {
              document.getElementById("bos-strategy")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="px-3 py-1.5 rounded-md text-xs font-medium text-[#14f5c7]/70 hover:text-[#14f5c7] hover:bg-[#14f5c7]/5 transition-all duration-200 border border-[#14f5c7]/20"
          >
            BOS Strategy
          </button>
        </div>

        <button
          className="lg:hidden p-2 text-white/60 hover:text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {mobileOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-[#0a0e1a]/95 backdrop-blur-xl border-b border-white/5 py-4">
          <div className="container flex flex-col gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  onCategoryClick(cat.id);
                  setMobileOpen(false);
                }}
                className="text-left px-4 py-2 text-sm text-white/60 hover:text-white hover:bg-white/5 rounded-md transition-colors"
              >
                <span className="inline-block w-2 h-2 rounded-full mr-3" style={{ backgroundColor: cat.color }} />
                {cat.title}
              </button>
            ))}
            <button
              onClick={() => {
                document.getElementById("bos-strategy")?.scrollIntoView({ behavior: "smooth" });
                setMobileOpen(false);
              }}
              className="text-left px-4 py-2 text-sm text-[#14f5c7]/70 hover:text-[#14f5c7] hover:bg-[#14f5c7]/5 rounded-md transition-colors"
            >
              BOS Strategy
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
