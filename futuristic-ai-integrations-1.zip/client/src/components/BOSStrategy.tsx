export default function BOSStrategy() {
  const strategies = [
    {
      phase: "01",
      title: "Establish a Cross-Disciplinary AI Research Lab",
      description: "Create a dedicated lab that combines AI/ML engineers with biologists, neuroscientists, materials scientists, and urban planners. The whitespace exists because these fields are siloed — BOS bridges them.",
      actions: [
        "Recruit PhDs from non-CS fields (epigenetics, mycology, fluid dynamics)",
        "Create 'convergence fellowships' pairing AI researchers with domain experts",
        "Build proprietary datasets at the intersection of AI + biology/ecology/architecture",
      ],
      color: "#00f0ff",
    },
    {
      phase: "02",
      title: "File Provisional Patents on All 25 Integrations Immediately",
      description: "Provisional patents are inexpensive ($320 each) and establish priority date for 12 months. File all 25 now to claim the whitespace before competitors discover it.",
      actions: [
        "Engage a patent attorney specializing in AI/biotech convergence",
        "File provisionals on each integration's core method and system architecture",
        "Use the 12-month window to develop MVPs and convert to full utility patents",
      ],
      color: "#ffb347",
    },
    {
      phase: "03",
      title: "Build Minimum Viable Prototypes for the Top 5",
      description: "Prioritize integrations with the shortest path to demonstrable results: Mycorrhizal Network Manager, Tectonic Sonification, Crowd Fluid Dynamics, Soil-to-Plate AI, and Vocal Preservation.",
      actions: [
        "Partner with university research labs for access to specialized equipment",
        "Develop simulation-based proofs-of-concept before physical prototypes",
        "Document all results for both patent strengthening and investor pitch decks",
      ],
      color: "#a78bfa",
    },
    {
      phase: "04",
      title: "Create an Open-Source SDK Layer",
      description: "Release open-source toolkits for the foundational layers (sensor interfaces, signal processing, data pipelines) while keeping the AI models proprietary. This builds community and ecosystem lock-in.",
      actions: [
        "Open-source the 'starter code' frameworks shown on this site",
        "Build developer community around BOS's AI integration standards",
        "Monetize through proprietary model APIs, enterprise support, and hardware partnerships",
      ],
      color: "#14f5c7",
    },
    {
      phase: "05",
      title: "Secure Strategic Partnerships Before Competitors Emerge",
      description: "Each integration requires domain-specific hardware or data access. Lock in exclusive partnerships with sensor manufacturers, biotech firms, and smart city initiatives.",
      actions: [
        "Partner with Illumina/PacBio for epigenetic sequencing integrations",
        "Collaborate with smart city programs (Singapore, Barcelona, Seoul) for urban AI",
        "Engage agricultural tech companies for soil-to-plate and mycorrhizal systems",
      ],
      color: "#f472b6",
    },
    {
      phase: "06",
      title: "Develop a Regulatory Strategy Early",
      description: "Many of these integrations touch human biology, consciousness, and environmental systems. Being first to engage regulators positions BOS as the trusted standard-setter, not a disruptor to be regulated.",
      actions: [
        "Engage FDA/EMA for bio-integration products before they create restrictive rules",
        "Propose industry standards for AI-biological interfaces to ISO/IEEE",
        "Build an ethics advisory board with credibility in bioethics and AI safety",
      ],
      color: "#00f0ff",
    },
    {
      phase: "07",
      title: "Launch a 'Futures Fund' to Attract Visionary Capital",
      description: "Traditional VCs may not understand 10-year convergence plays. Create a dedicated investment vehicle that attracts patient capital from sovereign wealth funds, family offices, and deep-tech investors.",
      actions: [
        "Structure as a 10-year fund with milestone-based capital deployment",
        "Target $50M initial raise focused on the 5 nearest-term integrations",
        "Use patent portfolio as collateral and IP valuation for fundraising",
      ],
      color: "#ffb347",
    },
  ];

  return (
    <section id="bos-strategy" className="relative py-24 sm:py-32">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e1a] via-[#0a1a2a] to-[#0a0e1a]" />

      <div className="relative container max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-16 text-center">
          <span className="inline-block font-mono text-xs tracking-[0.3em] uppercase text-[#14f5c7]/80 mb-4 border border-[#14f5c7]/20 px-4 py-1.5 rounded-full">
            Strategic Playbook
          </span>
          <h2
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            How BOS Becomes the{" "}
            <span className="bg-gradient-to-r from-[#14f5c7] to-[#00f0ff] bg-clip-text text-transparent">
              Leader
            </span>{" "}
            in AI Integration
          </h2>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            A seven-phase roadmap to own the convergence whitespace before anyone else realizes it exists.
          </p>
        </div>

        {/* Strategy cards with timeline */}
        <div className="relative">
          {/* Vertical timeline line */}
          <div className="absolute left-6 sm:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-[#14f5c7]/50 via-[#00f0ff]/30 to-transparent" />

          <div className="space-y-8">
            {strategies.map((strategy) => (
              <div key={strategy.phase} className="relative pl-16 sm:pl-20">
                {/* Timeline node */}
                <div
                  className="absolute left-4 sm:left-6 top-6 w-4 h-4 rounded-full border-2"
                  style={{ borderColor: strategy.color, backgroundColor: `${strategy.color}20` }}
                >
                  <div
                    className="absolute inset-1 rounded-full animate-glow-pulse"
                    style={{ backgroundColor: strategy.color }}
                  />
                </div>

                {/* Card */}
                <div className="rounded-xl border border-white/5 bg-white/[0.02] backdrop-blur-sm p-6 sm:p-8 hover:bg-white/[0.04] hover:border-white/10 transition-all duration-300">
                  <div className="flex items-center gap-3 mb-3">
                    <span
                      className="font-mono text-sm font-bold"
                      style={{ color: strategy.color }}
                    >
                      Phase {strategy.phase}
                    </span>
                  </div>
                  <h3
                    className="text-lg sm:text-xl font-bold text-white mb-3"
                    style={{ fontFamily: "var(--font-heading)" }}
                  >
                    {strategy.title}
                  </h3>
                  <p className="text-sm text-white/50 leading-relaxed mb-4">
                    {strategy.description}
                  </p>
                  <div className="space-y-2">
                    {strategy.actions.map((action, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <svg
                          className="w-4 h-4 mt-0.5 shrink-0"
                          style={{ color: strategy.color }}
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                        <span className="text-sm text-white/60">{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center p-8 rounded-xl border border-[#14f5c7]/20 bg-[#14f5c7]/5">
          <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-heading)" }}>
            The Window Is Open Now
          </h3>
          <p className="text-white/50 text-sm max-w-xl mx-auto">
            These integrations require 3-7 years of development. The organizations that begin today will own 
            the standards, patents, and talent pipelines that define the next era of AI. BOS must move first.
          </p>
        </div>
      </div>
    </section>
  );
}
