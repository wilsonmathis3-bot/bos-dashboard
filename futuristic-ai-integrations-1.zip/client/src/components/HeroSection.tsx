export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663283084951/VoBjRMdPnbNXtP7EgJQhuX/hero-neural-network-66ndwA8oDkZq2ZcwAAsM2Y.webp)`,
        }}
      />
      {/* Dark overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e1a]/70 via-[#0a0e1a]/40 to-[#0a0e1a]" />

      {/* Content */}
      <div className="relative z-10 container max-w-5xl mx-auto text-center px-4 pt-24">
        <div className="animate-fade-up" style={{ animationDelay: "0.1s" }}>
          <span className="inline-block font-mono text-xs tracking-[0.3em] uppercase text-[#00f0ff]/80 mb-6 border border-[#00f0ff]/20 px-4 py-1.5 rounded-full">
            Unpatented &middot; Undeveloped &middot; Inevitable
          </span>
        </div>

        <h1
          className="text-4xl sm:text-5xl md:text-7xl font-bold leading-[1.1] mb-6 animate-fade-up"
          style={{ animationDelay: "0.25s", fontFamily: "var(--font-heading)" }}
        >
          <span className="text-white">25 Futuristic</span>
          <br />
          <span className="bg-gradient-to-r from-[#00f0ff] via-[#a78bfa] to-[#ffb347] bg-clip-text text-transparent">
            AI Integrations
          </span>
        </h1>

        <p
          className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed mb-10 animate-fade-up"
          style={{ animationDelay: "0.4s" }}
        >
          A curated atlas of highly probable AI applications that exist in the whitespace — 
          concepts nobody has started working on or patenting yet.
        </p>

        <div className="animate-fade-up" style={{ animationDelay: "0.55s" }}>
          <button
            onClick={() => {
              document.getElementById("biological")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="group inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white/5 border border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20 transition-all duration-200"
          >
            <span className="text-sm font-medium">Explore the Atlas</span>
            <svg
              className="w-4 h-4 group-hover:translate-y-0.5 transition-transform"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </button>
        </div>

        {/* Stats bar */}
        <div
          className="mt-20 grid grid-cols-3 gap-8 max-w-lg mx-auto animate-fade-up"
          style={{ animationDelay: "0.7s" }}
        >
          <div className="text-center">
            <div className="font-mono text-2xl font-bold text-[#00f0ff]">25</div>
            <div className="text-xs text-white/40 mt-1">Integrations</div>
          </div>
          <div className="text-center">
            <div className="font-mono text-2xl font-bold text-[#ffb347]">5</div>
            <div className="text-xs text-white/40 mt-1">Domains</div>
          </div>
          <div className="text-center">
            <div className="font-mono text-2xl font-bold text-[#a78bfa]">0</div>
            <div className="text-xs text-white/40 mt-1">Patents Filed</div>
          </div>
        </div>
      </div>
    </section>
  );
}
