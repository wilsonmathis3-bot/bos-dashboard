import { useState } from "react";
import { Integration, Category } from "@/data/integrations";
import { codeSnippets } from "@/data/codeSnippets";

interface IntegrationCardProps {
  integration: Integration;
  category: Category;
  index: number;
}

export default function IntegrationCard({ integration, category, index }: IntegrationCardProps) {
  const [expanded, setExpanded] = useState(false);
  const snippet = codeSnippets[integration.id];

  return (
    <div
      className="group relative rounded-xl border border-white/5 bg-white/[0.02] backdrop-blur-sm hover:bg-white/[0.04] hover:border-white/10 transition-all duration-300 overflow-hidden"
      style={{
        animationDelay: `${index * 0.08}s`,
      }}
    >
      {/* Glow accent */}
      <div
        className="absolute top-0 left-0 w-full h-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: `linear-gradient(90deg, transparent, ${category.color}, transparent)` }}
      />

      <div className="p-5 sm:p-6">
        {/* Header */}
        <div className="flex items-start gap-4 mb-3">
          <span
            className="font-mono text-lg font-bold shrink-0 opacity-60"
            style={{ color: category.color }}
          >
            {String(integration.id).padStart(2, "0")}
          </span>
          <h3 className="text-base sm:text-lg font-semibold text-white/90 leading-snug" style={{ fontFamily: "var(--font-heading)" }}>
            {integration.title}
          </h3>
        </div>

        {/* Description */}
        <p className="text-sm text-white/50 leading-relaxed ml-10 mb-4">
          {integration.description}
        </p>

        {/* Code snippet toggle */}
        {snippet && (
          <div className="ml-10">
            <button
              onClick={() => setExpanded(!expanded)}
              className="inline-flex items-center gap-2 text-xs font-mono px-3 py-1.5 rounded-md border transition-all duration-200"
              style={{
                color: category.color,
                borderColor: `${category.color}33`,
                backgroundColor: expanded ? `${category.color}10` : "transparent",
              }}
            >
              <svg
                className={`w-3 h-3 transition-transform duration-200 ${expanded ? "rotate-90" : ""}`}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              {expanded ? "Hide" : "View"} Starter Code
            </button>

            {expanded && (
              <div className="mt-3 rounded-lg bg-[#0d1117] border border-white/5 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 border-b border-white/5 bg-white/[0.02]">
                  <span className="text-xs font-mono text-white/40">{snippet.language}</span>
                  <span className="text-xs font-mono text-white/30">{snippet.filename}</span>
                </div>
                <pre className="p-4 overflow-x-auto text-xs leading-relaxed">
                  <code className="text-white/70 font-mono">{snippet.code}</code>
                </pre>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
